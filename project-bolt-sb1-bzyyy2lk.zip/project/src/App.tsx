import React from 'react';
import { MarketOverview } from './components/MarketOverview';
import { PriceChart } from './components/PriceChart';
import { TrendingAssets } from './components/TrendingAssets';
import { AIPredictions } from './components/AIPredictions';
import { Wallet, LineChart, Layers, Bell, Settings } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-background text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-accent-purple/10 backdrop-blur-sm bg-background/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <LineChart className="w-8 h-8 text-accent-purple" />
              <span className="text-xl font-bold">CryptoMatrix</span>
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#" className="flex items-center space-x-2 text-gray-400 hover:text-accent-cyan transition-colors">
                <LineChart className="w-4 h-4" />
                <span>Markets</span>
              </a>
              <a href="#" className="flex items-center space-x-2 text-gray-400 hover:text-accent-cyan transition-colors">
                <Layers className="w-4 h-4" />
                <span>DeFi</span>
              </a>
              <a href="#" className="flex items-center space-x-2 text-gray-400 hover:text-accent-cyan transition-colors">
                <Wallet className="w-4 h-4" />
                <span>Portfolio</span>
              </a>
            </nav>
            <div className="flex items-center space-x-4">
              <button className="p-2 text-gray-400 hover:text-accent-cyan transition-colors">
                <Bell className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-400 hover:text-accent-cyan transition-colors">
                <Settings className="w-5 h-5" />
              </button>
              <button className="px-4 py-2 bg-accent-purple/20 text-accent-purple rounded-lg hover:bg-accent-purple/30 transition-colors">
                Connect Wallet
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Hero Section */}
          <section className="text-center space-y-4">
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-accent-purple via-accent-cyan to-accent-purple bg-clip-text text-transparent">
              AI-Powered Crypto Analytics
            </h1>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Institutional-grade tools and real-time insights powered by advanced AI algorithms
            </p>
          </section>

          {/* Market Overview */}
          <section className="space-y-6">
            <h2 className="text-2xl font-bold">Market Overview</h2>
            <MarketOverview />
          </section>

          {/* Price Chart & Trending Assets */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <PriceChart />
            </div>
            <div>
              <TrendingAssets />
            </div>
          </div>

          {/* AI Predictions */}
          <section>
            <AIPredictions />
          </section>
        </div>
      </main>
    </div>
  );
}

export default App;