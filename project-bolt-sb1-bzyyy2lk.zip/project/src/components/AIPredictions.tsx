import React from 'react';
import { GlassCard } from './ui/GlassCard';
import { Brain, TrendingUp, BarChart2, AlertTriangle, Activity, Globe, Zap, Lock } from 'lucide-react';

export function AIPredictions() {
  return (
    <GlassCard className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Brain className="w-7 h-7 text-accent-purple animate-pulse" />
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
          </div>
          <div>
            <h3 className="text-xl font-bold bg-gradient-to-r from-accent-purple via-accent-cyan to-emerald-500 bg-clip-text text-transparent">
              AI Market Intelligence
            </h3>
            <p className="text-xs text-gray-400">Powered by Advanced Neural Networks</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <span className="text-xs text-gray-400">Last updated: 5s ago</span>
          <span className="text-xs bg-emerald-500/20 text-emerald-500 px-2 py-1 rounded-full flex items-center">
            <Lock className="w-3 h-3 mr-1" />
            Live Feed
          </span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-gradient-to-br from-accent-purple/10 via-accent-cyan/5 to-emerald-500/10 border border-accent-purple/20 hover:border-accent-purple/40 transition-all duration-300">
          <div className="flex items-center space-x-2 mb-3">
            <TrendingUp className="w-5 h-5 text-accent-purple" />
            <span className="text-sm font-medium">BTC Price Forecast</span>
          </div>
          <p className="text-3xl font-bold text-transparent bg-gradient-to-r from-accent-purple to-accent-cyan bg-clip-text mb-2">
            $215,450
          </p>
          <p className="text-sm text-gray-400">Expected by March 2025</p>
          <div className="mt-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-400">AI Confidence</span>
              <span className="text-xs text-accent-cyan">92%</span>
            </div>
            <div className="h-2 w-full bg-accent-purple/20 rounded-full overflow-hidden">
              <div className="h-full w-[92%] bg-gradient-to-r from-accent-purple to-accent-cyan rounded-full" />
            </div>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-gradient-to-br from-accent-cyan/10 via-emerald-500/5 to-accent-purple/10 border border-accent-cyan/20 hover:border-accent-cyan/40 transition-all duration-300">
          <div className="flex items-center space-x-2 mb-3">
            <Globe className="w-5 h-5 text-accent-cyan" />
            <span className="text-sm font-medium">Market Sentiment</span>
          </div>
          <p className="text-3xl font-bold text-transparent bg-gradient-to-r from-accent-cyan to-emerald-500 bg-clip-text mb-2">
            Super Bullish
          </p>
          <p className="text-sm text-gray-400">Based on 1.2M signals</p>
          <div className="mt-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Social Signals</span>
              <span className="text-emerald-500">+92%</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">News Sentiment</span>
              <span className="text-emerald-500">+88%</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">On-Chain Activity</span>
              <span className="text-emerald-500">High</span>
            </div>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-gradient-to-br from-emerald-500/10 via-accent-purple/5 to-accent-cyan/10 border border-emerald-500/20 hover:border-emerald-500/40 transition-all duration-300">
          <div className="flex items-center space-x-2 mb-3">
            <Zap className="w-5 h-5 text-emerald-500" />
            <span className="text-sm font-medium">Market Dynamics</span>
          </div>
          <p className="text-3xl font-bold text-transparent bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text mb-2">
            Strong Buy
          </p>
          <p className="text-sm text-gray-400">All indicators aligned</p>
          <div className="mt-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Buy Pressure</span>
              <span className="text-emerald-500">Very High</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Volatility</span>
              <span className="text-amber-500">Moderate</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Trend Strength</span>
              <span className="text-emerald-500">85%</span>
            </div>
          </div>
        </div>
      </div>

      <div className="text-sm text-gray-400 border-t border-accent-purple/10 pt-4">
        <p className="flex items-center space-x-2">
          <Brain className="w-4 h-4 text-accent-purple" />
          <span>AI predictions are based on real-time analysis of 500+ market indicators, social sentiment, and on-chain metrics</span>
        </p>
      </div>
    </GlassCard>
  );
}