import React from 'react';
import { GlassCard } from './ui/GlassCard';
import { TrendingUp, TrendingDown, Star, BarChart2, Zap, Globe } from 'lucide-react';

const trendingAssets = [
  { name: 'Bitcoin', symbol: 'BTC', price: 198450.32, change: 3.24, volume: '142.8B', marketCap: '4.12T', dominance: '48.2%' },
  { name: 'Ethereum', symbol: 'ETH', price: 12845.76, change: 5.87, volume: '68.4B', marketCap: '1.54T', dominance: '18.1%' },
  { name: 'Solana', symbol: 'SOL', price: 684.32, change: 4.92, volume: '14.2B', marketCap: '298.3B', dominance: '3.5%' },
  { name: 'Cardano', symbol: 'ADA', price: 4.82, change: 2.45, volume: '8.8B', marketCap: '168.4B', dominance: '2.0%' },
  { name: 'Avalanche', symbol: 'AVAX', price: 248.18, change: 6.73, volume: '12.1B', marketCap: '89.8B', dominance: '1.1%' },
  { name: 'Polkadot', symbol: 'DOT', price: 89.45, change: 4.28, volume: '6.4B', marketCap: '54.2B', dominance: '0.6%' }
];

export function TrendingAssets() {
  return (
    <GlassCard>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Star className="w-6 h-6 text-amber-400" />
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-accent-cyan rounded-full animate-pulse" />
          </div>
          <h3 className="text-xl font-bold bg-gradient-to-r from-amber-400 to-accent-purple bg-clip-text text-transparent">
            Top Performing Assets
          </h3>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-xs text-gray-400">Last updated: Feb 18, 2025</span>
          <button className="text-sm bg-accent-purple/20 text-accent-purple px-3 py-1 rounded-full hover:bg-accent-purple/30 transition-colors">
            View All
          </button>
        </div>
      </div>
      <div className="space-y-4">
        {trendingAssets.map((asset) => (
          <div key={asset.symbol} 
               className="group flex items-center justify-between p-4 rounded-xl hover:bg-white/5 transition-all duration-300 border border-transparent hover:border-accent-purple/20">
            <div className="flex items-center space-x-4">
              <div className={`p-3 rounded-full ${asset.change >= 0 ? 'bg-emerald-500/20' : 'bg-rose-500/20'} 
                             group-hover:scale-110 transition-transform duration-300`}>
                {asset.change >= 0 ? (
                  <TrendingUp className="w-5 h-5 text-emerald-500" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-rose-500" />
                )}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <p className="font-bold text-lg">{asset.name}</p>
                  <span className="text-sm px-2 py-0.5 rounded-full bg-gray-800 text-gray-400">{asset.symbol}</span>
                </div>
                <div className="flex items-center space-x-4 mt-1">
                  <span className="text-xs text-gray-400 flex items-center">
                    <Globe className="w-3 h-3 mr-1" />
                    Vol: ${asset.volume}
                  </span>
                  <span className="text-xs text-gray-400 flex items-center">
                    <BarChart2 className="w-3 h-3 mr-1" />
                    MCap: ${asset.marketCap}
                  </span>
                  <span className="text-xs text-accent-cyan flex items-center">
                    <Zap className="w-3 h-3 mr-1" />
                    {asset.dominance}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="font-bold text-lg bg-gradient-to-r from-accent-purple to-accent-cyan bg-clip-text text-transparent">
                ${asset.price.toLocaleString()}
              </p>
              <p className={`flex items-center justify-end space-x-1 ${asset.change >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                <BarChart2 className="w-3 h-3" />
                <span className="font-medium">{asset.change >= 0 ? '+' : ''}{asset.change}%</span>
              </p>
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}