import React from 'react';
import { cn } from '../../lib/utils';

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

export function GlassCard({ children, className, ...props }: GlassCardProps) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-xl border border-accent-purple/10',
        'bg-background/30 p-6 backdrop-blur-sm',
        'before:absolute before:inset-0',
        'before:animate-gradient-xy',
        'before:bg-gradient-to-r before:from-accent-purple/10 before:via-accent-cyan/10 before:to-accent-purple/10',
        'before:-z-10',
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}