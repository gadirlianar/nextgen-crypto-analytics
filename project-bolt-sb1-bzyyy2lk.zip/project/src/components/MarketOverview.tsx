import React from 'react';
import { TrendingUp, Activity, DollarSign, Globe, Zap, Clock, Wallet, BarChart as ChartBar } from 'lucide-react';
import { GlassCard } from './ui/GlassCard';

export function MarketOverview() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <GlassCard className="flex items-center space-x-4 group hover:border-accent-purple/40 transition-all duration-300">
        <div className="p-3 rounded-full bg-gradient-to-br from-accent-purple/20 to-accent-cyan/20 group-hover:scale-110 transition-transform duration-300">
          <Globe className="w-6 h-6 text-accent-purple" />
        </div>
        <div>
          <p className="text-sm text-gray-400">Global Market Cap</p>
          <p className="text-xl font-bold bg-gradient-to-r from-accent-purple to-accent-cyan bg-clip-text text-transparent">
            $8.54T
          </p>
          <p className="text-xs text-emerald-500">+8.23% (24h)</p>
        </div>
      </GlassCard>
      
      <GlassCard className="flex items-center space-x-4 group hover:border-accent-cyan/40 transition-all duration-300">
        <div className="p-3 rounded-full bg-gradient-to-br from-accent-cyan/20 to-emerald-500/20 group-hover:scale-110 transition-transform duration-300">
          <Activity className="w-6 h-6 text-accent-cyan" />
        </div>
        <div>
          <p className="text-sm text-gray-400">24h Volume</p>
          <p className="text-xl font-bold bg-gradient-to-r from-accent-cyan to-emerald-500 bg-clip-text text-transparent">
            $384.6B
          </p>
          <p className="text-xs text-gray-400">+12.8M transactions</p>
        </div>
      </GlassCard>
      
      <GlassCard className="flex items-center space-x-4 group hover:border-amber-500/40 transition-all duration-300">
        <div className="p-3 rounded-full bg-gradient-to-br from-amber-500/20 to-orange-500/20 group-hover:scale-110 transition-transform duration-300">
          <Wallet className="w-6 h-6 text-amber-500" />
        </div>
        <div>
          <p className="text-sm text-gray-400">Total DeFi TVL</p>
          <p className="text-xl font-bold bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            $892.4B
          </p>
          <p className="text-xs text-amber-500">+5.8% (24h)</p>
        </div>
      </GlassCard>

      <GlassCard className="flex items-center space-x-4 group hover:border-emerald-500/40 transition-all duration-300">
        <div className="p-3 rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/20 group-hover:scale-110 transition-transform duration-300">
          <ChartBar className="w-6 h-6 text-emerald-500" />
        </div>
        <div>
          <p className="text-sm text-gray-400">Market Sentiment</p>
          <p className="text-xl font-bold bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text text-transparent">
            Extreme Greed
          </p>
          <p className="text-xs text-emerald-500">Score: 88/100</p>
        </div>
      </GlassCard>
    </div>
  );
}