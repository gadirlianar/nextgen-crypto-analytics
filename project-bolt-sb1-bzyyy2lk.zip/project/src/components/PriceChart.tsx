import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { GlassCard } from './ui/GlassCard';

const mockData = Array.from({ length: 100 }, (_, i) => ({
  date: new Date(2024, 0, i + 1),
  price: 40000 + Math.random() * 10000 + Math.sin(i / 10) * 5000
}));

export function PriceChart() {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;
    const margin = { top: 20, right: 20, bottom: 30, left: 60 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Clear previous content
    svg.selectAll("*").remove();

    // Create scales
    const xScale = d3.scaleTime()
      .domain(d3.extent(mockData, d => d.date) as [Date, Date])
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([d3.min(mockData, d => d.price) as number * 0.99, d3.max(mockData, d => d.price) as number * 1.01])
      .range([innerHeight, 0]);

    // Create line generator
    const line = d3.line<typeof mockData[0]>()
      .x(d => xScale(d.date))
      .y(d => yScale(d.price))
      .curve(d3.curveMonotoneX);

    // Create gradient
    const gradient = svg.append("defs")
      .append("linearGradient")
      .attr("id", "line-gradient")
      .attr("gradientUnits", "userSpaceOnUse")
      .attr("x1", 0)
      .attr("y1", yScale(d3.min(mockData, d => d.price) as number))
      .attr("x2", 0)
      .attr("y2", yScale(d3.max(mockData, d => d.price) as number));

    gradient.append("stop")
      .attr("offset", "0%")
      .attr("stop-color", "#2DD4BF");

    gradient.append("stop")
      .attr("offset", "100%")
      .attr("stop-color", "#7C3AED");

    // Create the chart group
    const g = svg.append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Add the line path
    g.append("path")
      .datum(mockData)
      .attr("fill", "none")
      .attr("stroke", "url(#line-gradient)")
      .attr("stroke-width", 2)
      .attr("d", line);

    // Add area under the line
    const area = d3.area<typeof mockData[0]>()
      .x(d => xScale(d.date))
      .y0(innerHeight)
      .y1(d => yScale(d.price))
      .curve(d3.curveMonotoneX);

    g.append("path")
      .datum(mockData)
      .attr("fill", "url(#line-gradient)")
      .attr("fill-opacity", 0.1)
      .attr("d", area);

    // Add axes
    const xAxis = d3.axisBottom(xScale)
      .ticks(5)
      .tickFormat(d => d3.timeFormat("%b %d")(d as Date));

    const yAxis = d3.axisLeft(yScale)
      .ticks(5)
      .tickFormat(d => `$${d3.format(",.0f")(d)}`);

    g.append("g")
      .attr("transform", `translate(0,${innerHeight})`)
      .attr("class", "text-gray-400")
      .call(xAxis);

    g.append("g")
      .attr("class", "text-gray-400")
      .call(yAxis);

    // Style axis lines and text
    svg.selectAll(".domain")
      .attr("stroke", "rgba(156, 163, 175, 0.2)");
    svg.selectAll(".tick line")
      .attr("stroke", "rgba(156, 163, 175, 0.2)");
    svg.selectAll(".tick text")
      .attr("fill", "rgb(156, 163, 175)");

  }, []);

  return (
    <GlassCard className="w-full h-[400px] p-4">
      <svg ref={svgRef} className="w-full h-full"></svg>
    </GlassCard>
  );
}